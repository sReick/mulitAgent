package utils;

import fireFighters_MAS.Forester;
import repast.simphony.space.grid.Grid;

public class GridUtils {

	public static int chebiDistance(Forester f1, Forester f2, Grid<?> grid) {
		int x = grid.getLocation(f1).getX();
		int y = grid.getLocation(f1).getY();
		int xF = grid.getLocation(f2).getX();
		int yF = grid.getLocation(f2).getY();
		int fXDistance = Math.abs(xF - x), fYDistance = Math.abs(yF - y);
		return Math.max(fXDistance, fYDistance);
	}
}
