package fireFighters_MAS;

public class Message {
	// Local variables declaration
	private Knowledge k;

	/**
	 * Default constructor
	 */
	public Message() {

	}

	// Local getters
	public Knowledge getKnowledge() {
		return k;
	}

	// Local setters
	public void setKnowledge(Knowledge k) {
		this.k = k;
	}
}
