package fireFighters_MAS;

public enum Role {
	
	LEADER, FOLLOWER;

}
