package fireFighters_MAS;

public class Bounty {

	public static final int FIRE_REWARD = 100;
	
	public static final int BROADCAST = -100;
	
	public static final int LOCAL_MESSAGE = -20;
	
	public static final int NEIGHBOUR_TALK = -1;
	
}
